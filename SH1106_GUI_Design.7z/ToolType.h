#ifndef TOOLTYPE_H
#define TOOLTYPE_H


enum ToolType {
    Tool_Pen,
    Tool_Line,
    Tool_Rectangle,
    Tool_FilledRectangle,
    Tool_Circle
    // 之后可以继续添加 Triangle 等
};

#endif // TOOLTYPE_H
